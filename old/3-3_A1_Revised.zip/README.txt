CPSC 449 Java Assignment

Submitted by group 3-3

To run this program, compile main.java:

 $ javac main.java

Once compiled, the program can be run with the format of:
"java main <myInput> <myOutput>".

The input .txt file must be in the same directory as main.java 
and the output .txt file will be written in the same directory
with the name specified.

As an example, the following will generate a file called
output.txt if sample.txt is a valid set of constraints:

 $ java main sample.txt output.txt

Update: Saturday, Oct 12:
Every error message will be also be written to console AND in the output file as required by the TA.
