/**
 * CPSC449 Fall 2013 
 * @author team 3-3
 * 8 Oct 2013
 */

public class Assignment
{
	public String mTask;
	public boolean mForced;
}
